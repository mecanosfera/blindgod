= Wooden floor(CC-BY-SA) =
 * Horizontal wooden floor by Lanea Zimmerman (AKA Sharm)
 * Horizontal wooden floor with hole by Lanea Zimmerman (AKA Sharm) and Tuomo Untinen
 * Vertical wooden floor by Tuomo Untinen
 * Vertical wooden floor with hole by Tuomo Untinen
= Wooden wall topping (CC-BY-SA) =
 * Tuomo Untinen
= Pile of barrels =
 * Based LPC base tiles by Lanea Zimmerman (AKA Sharm)
= Decorational stuff (CC-BY-SA) =
 * Green bottle
 * Wine glass and bottle
 * Hanging sacks
 * Wall mounted rope and ropes
 * Wall mounted swords
 * Wall mounted kite shield
 * Wall hole
 By Tuomo Untinen
 * Small sack from LPC farming tileset by Daniel Eddeland (http://opengameart.org/content/lpc- farming-tilesets-magic-animations-and-ui-elements) 
 * Purple bottles and gray lantern from Hyptosis Mage city
 * Green and blue bottle by Tuomo Untinen
= Wall clock (CC-BY-SA) =
 * Lanea Zimmerman AKA Sharm
 * Tuomo Untinen (Scaled down and animation)
= Stone floor (CC-BY-SA)= 
 * Tuomo Untinen 
= Cobble stone floor (CC-BY-SA)= 
 * Based on LPC base tileset by Lanea Zimmerman (AKA Sharm)
= Cabinets and kitchen stuff including metal stove(CC-BY-SA) =
 * Based on LPC base tileset by Lanea Zimmerman (AKA Sharm)
 * Cutboard is made by Hyptosis
 * Sacks based on LPC farming tileset by Daniel Eddeland (http://opengameart.org/content/lpc- farming-tilesets-magic-animations-and-ui-elements) 
 * Spears by Tuomo Untinen
 * Vertical chest by Tuomo Untinen based on LPC base tiles Lanea Zimmerman (AKA Sharm)
Manuel Riecke (AKA MrBeast)
= Skull (CC-BY-SA) =
 * http://opengameart.org/content/lpc-dungeon-elements
 * Graphical artist Lanea Zimmerman AKA Sharm
 * Contributor William Thompson
= pile sacks =
 * LPC farming tileset by Daniel Eddeland (http://opengameart.org/content/lpc- farming-tilesets-magic-animations-and-ui-elements) 
= Pile of papers(CC-BY-SA) = 
 * Based on caeles papers
= Armor shelves(CC-BY-SA) =
 * Based on LPC base tileset by Lanea Zimmerman (AKA Sharm)
 * Armors by: Adapted by Matthew Krohn from art created by Johannes Sjölund
= Table lamp =
  * Curt
  * Sharm
  * Hyptosis
= Distiller =
 * Table is from LPC base tileset by Lanea Zimmerman (AKA Sharm)
 * Distiller by Tuomo Untinen
= Fireplace =
 * Tuomo Untinen
 * Inspired by Lanea Zimmerman (AKA Sharm) Fireplace

