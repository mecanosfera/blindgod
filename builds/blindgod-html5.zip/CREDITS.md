3rd-party tilesets and audios used in this project:
	
	Audio:

	"Confirmation sound" by Heshi - https://freesound.org/people/Heshl/sounds/269156/
	"UI confirmation Alert, A2" by InspectorJ - https://freesound.org/people/InspectorJ/sounds/403007/
	"Complete 0" by dogfishkid - https://freesound.org/people/dogfishkid/sounds/399388/
	"Monster idle" by deleted_user_4798915 - https://freesound.org/people/deleted_user_4798915/sounds/276298/


	Sprites:

	"LPC Tile Atlas2" by adrix89 - https://opengameart.org/content/lpc-tile-atlas2 - See assets/tilemaps/credits_lpc_tile_atlas2.md
	"[LPC] House interior and decorations" by Reemax - https://opengameart.org/content/lpc-house-interior-and-decorations - See assets/tilemaps/credits_house_interior.md
	"[LPC] House Insides" by Sharm - https://opengameart.org/content/lpc-house-insides
	"[LPC] Dungeon elements" by William Thompsonj and Sharm  - https://opengameart.org/content/lpc-dungeon-elements


