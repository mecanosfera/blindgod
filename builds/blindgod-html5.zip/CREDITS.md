3rd-party tilemaps and sound used in this project:
	
	"Confirmation sound" by Heshi - https://freesound.org/people/Heshl/sounds/269156/
	"UI confirmation Alert, A2" by InspectorJ - https://freesound.org/people/InspectorJ/sounds/403007/
	"Complete 0" by dogfishkid - https://freesound.org/people/dogfishkid/sounds/399388/
	"Monster idle" by deleted_user_4798915 - https://freesound.org/people/deleted_user_4798915/sounds/276298/


